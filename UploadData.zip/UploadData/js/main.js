var config = {
    apiKey: "AIzaSyCoSa_3upryZCjoQ7DlTLzc9ISMhKzog_8",
    authDomain: "comp3150project.firebaseapp.com",
    databaseURL: "https://comp3150project.firebaseio.com",
    storageBucket: "comp3150project.appspot.com",
    messagingSenderId: "857460931484"
};
firebase.initializeApp(config);
var database = firebase.database();
getAllSubjects();
getFaculties();
function getAllSubjects(){
    var subjectsRef = database.ref('Prerequisites');
    subjectsRef.on('value', function(snapshot){
        data = snapshot.val();
        displayCsecSubjects(data.CSEC);
        displayCapeSubjects(data.CAPECompressed);
    });
}
function getFaculties(){
    var facultiesRef = database.ref('Faculties');
    facultiesRef.on('value', function(snapshot){
        data = snapshot.val();
        for(var faculty in data){
            $('#faculties').append('<option>' + data[faculty] + '</option>');
        }
    });
}
function displayCsecSubjects(data){
    for(var subject in data){
        $('#cxc_subjects_option1').append('<option>'+ data[subject] +'</option>');
        $('#cxc_subjects_option2').append('<option>'+ data[subject] +'</option>');
    }
}
function displayCapeSubjects(data){
    for(var subject in data){
        $('#cape_subjects_option1').append('<option>'+ data[subject] +'</option>');
        $('#cape_subjects_option2').append('<option>'+ data[subject] +'</option>');
    }
}
function saveToFirebase(record){
    console.log(record);
    var ProgramRef = database.ref('UWIPrograms');
    ProgramRef.push().set(record); 
}
