var app = angular.module('myApp', ['ui.bootstrap']);

app.controller('myCtrl', function($scope, $uibModal, $log){
    $scope.message = "Programme Upload";
    $scope.cxcSubjectsList = [];
    $scope.capeSubjectsList = [];
    $scope.capeStatements = [];
    $scope.cxcStatements = [];
    $scope.addCXCSubject = function(){
        var statement = '';
        var option2;
        statement = statement + $scope.cxcRequirements_option1;
        if($scope.cxcRequirements_option2 != null){
            statement = statement + ' OR ' + $scope.cxcRequirements_option2;
            option2 = $scope.cxcRequirements_option2;
        }
        else option2 = "";
        var subject = {
            "option1" : $scope.cxcRequirements_option1,
            "option2" : option2
        }
        $scope.cxcStatements.push(statement);
        $scope.cxcSubjectsList.push(subject);
        $scope.cxcRequirements_option1 = "";
        $scope.cxcRequirements_option2 = "";
    }
    $scope.addCAPESubject = function(){
        var statement = '';
        var option2;
        statement = statement + $scope.capeRequirements_option1;
        if($scope.capeRequirements_option2 != null){
            statement = statement + ' OR ' + $scope.capeRequirements_option2;
            option2 = $scope.capeRequirements_option2;
        }
        else option2 = "";
        var subject = {
            "option1" : $scope.capeRequirements_option1,
            "option2" : option2
        }
        $scope.capeStatements.push(statement);
        $scope.capeSubjectsList.push(subject);
        $scope.capeRequirements_option1 = "";
        $scope.capeRequirements_option2 = "";
        
    }
    var save = function(){
        var numberCAPEPasses;
        if($scope.numberCAPEPasses == null){
            numberCAPEPasses = '0';
        }
        else numberCAPEPasses = $scope.numberCAPEPasses;
        console.log("Hello World");
        var program = {
            "title" : $scope.programName,
            "type" : $scope.type,
            "time" : $scope.programTime,
            "faculty" : $scope.faculty,
            "requirements" : {
                cxc: {
                    "numberOfPasses" : $scope.numberCXCPasses,
                    "required" : $scope.cxcSubjectsList 
                },
                cape: {
                    "numberOfPasses" : numberCAPEPasses,
                    "required" : $scope.capeSubjectsList
                }
            }
            
        }
        //saveToFirebase(program);
        return program;
    }
    $scope.open = function(size){
        var myProgramme = save();
        console.log(myProgramme);
        var modalInstance = $uibModal.open({
            templateUrl: 'myModalContent.html',
            controller: 'ModalInstanceCtrl',
            size: size,
            resolve: {
                programme: function(){
                    return myProgramme;
                }
            }
        });
    }
});
app.controller('ModalInstanceCtrl', function($scope, $uibModalInstance, programme){
    $scope.programme = programme;
    var cxcRequirements = programme.requirements.cxc.required;
    var capeRequirements = programme.requirements.cape.required;
    $scope.cxcNumPasses = programme.requirements.cxc.numberOfPasses + " CXC passes Required";
    $scope.capeNumPasses = programme.requirements.cape.numberOfPasses + " CAPE passes Required";
    $scope.cxcRequired = [];
    $scope.capeRequired = [];
    if(cxcRequirements != null && cxcRequirements.length > 0){
        for(i = 0; i < cxcRequirements.length; i++){
            var currentString = "";
            current = cxcRequirements[i];
            currentString += current.option1;
            if(current.option2 != ""){
                currentString += " OR " + current.option2;
            }
            $scope.cxcRequired.push(currentString);
        }
    }
    if(capeRequirements != null && capeRequirements.length > 0){
        for(j = 0; j < capeRequirements.length; j++){
            var currentCapeString = "";
            currentCape = capeRequirements[j];
            currentCapeString += currentCape.option1;
            if(currentCape.option2 != ""){
                currentCapeString += " OR " + currentCape.option2;
            }
            $scope.capeRequired.push(currentCapeString);
        }
    }
    $scope.ok = function(){
        saveToFirebase(programme);
        $uibModalInstance.close();
    };
    $scope.cancel = function(){
        $uibModalInstance.dismiss('cancel');
    }
});